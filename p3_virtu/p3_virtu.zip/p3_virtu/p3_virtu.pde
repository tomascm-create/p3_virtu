import processing.pdf.*;

void setup() {
  size(428*2,291*2,PDF,"p3_virtutomas.pdf");
  frameRate(2); 
}

void draw() {
  background(255);
  float desplazamiento = 80;
  // CENTRO
  hugo(random(width/2 - CENTER - 50, width/2 - 50), random(height/2 - CENTER, height/2 + CENTER) - desplazamiento);
  sara(random(width/2 + 50, width/2 + CENTER + 50), random(height/2 - CENTER, height/2 + CENTER) - desplazamiento);
  
  // Cuadrado izq
  aitana(random(width/4 - 100, width/4 + 100), random(height/4 + 10, height/4 + 60) - desplazamiento);
  magda(random(width/4 - 100, width/4 + 100), random(height/4 + 80, height/4 + 120) - desplazamiento);

  // Cuadrado der
  gala(random(width*3/4 - 100, width*3/4 + 100), random(height/4 - 120, height/4 - 40) - desplazamiento);
  borja(random(width*3/4 - 100, width*3/4 + 100), random(height/4 + 10, height/4 + 60) - desplazamiento);
  virtu(random(width*3/4 - 100, width*3/4 + 100), random(height/4 + 80, height/4 + 120) - desplazamiento);

  // Cuadrado izq
  patri(random(width/4 - 100, width/4 + 100), random(height*3/4 - 120, height*3/4 - 40) - desplazamiento);
  lucas(random(width/4 - 100, width/4 + 100), random(height*3/4 - 10, height*3/4 + 30) - desplazamiento);
  bea(random(width/4 - 100, width/4 + 100), random(height*3/4 + 40, height*3/4 + 80) - desplazamiento);

  // Cuadrado der
  calin(random(width*3/4 - 100, width*3/4 + 100), random(height*3/4 - 120, height*3/4 - 40) - desplazamiento);
  geraldine(random(width*3/4 - 100, width*3/4 + 100), random(height*3/4 - 10, height*3/4 + 30) - desplazamiento);
  alba(random(width*3/4 - 100, width*3/4 + 100), random(height*3/4 + 40, height*3/4 + 80) - desplazamiento);
  
  PGraphicsPDF pdf = (PGraphicsPDF) g;  // Get the renderer

  // When finished drawing, quit and save the file
  if (frameCount == 10) {
    exit();
  } else {
    pdf.nextPage();  // Tell it to go to the next page
  }
}
